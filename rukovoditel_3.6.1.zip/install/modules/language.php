<h3>Language/Язык</h3>
<ul class="list-unstyled lng-list">
    <li><a href="index.php?step=checking_environment&lng=english" class="btn btn-default"><img src="icons/us.png" bolder="0" style="vertical-align:middle">&nbsp;English</a></li>
    <li><a href="index.php?step=checking_environment&lng=russian" class="btn btn-default"><img src="icons/ru.png" bolder="0" style="vertical-align:middle">&nbsp;Русский</a></li>
    <li><a href="index.php?step=checking_environment&lng=german" class="btn btn-default"><img src="icons/de.png" bolder="0" style="vertical-align:middle">&nbsp;German</a></li>
    <li><a href="index.php?step=checking_environment&lng=italian" class="btn btn-default"><img src="icons/it.png" bolder="0" style="vertical-align:middle">&nbsp;Italian</a></li>
    <li><a href="index.php?step=checking_environment&lng=chinese" class="btn btn-default"><img src="icons/cn.png" bolder="0" style="vertical-align:middle">&nbsp;Chinese</a></li>    
</ul>

<style>
    .lng-list{
        columns: 2;
    }
    
    .lng-list li{
        padding-bottom: 10px;
    }
</style>    


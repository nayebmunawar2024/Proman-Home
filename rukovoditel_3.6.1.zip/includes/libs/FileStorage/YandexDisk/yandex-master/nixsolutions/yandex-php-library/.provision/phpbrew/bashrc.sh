#!/bin/sh
export PHPBREW_HOME=/opt/phpbrew
export PHPBREW_ROOT=/opt/phpbrew
source /opt/phpbrew/bashrc